'use strict';

export const port = '3000';
export const distance_threshold = '5'; // threshold: distance between user location and cab location
