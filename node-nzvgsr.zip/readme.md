npm install
npm start
